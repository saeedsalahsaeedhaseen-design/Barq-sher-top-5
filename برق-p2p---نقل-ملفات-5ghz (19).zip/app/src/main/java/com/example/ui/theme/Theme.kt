package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val BarqDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color(0xFF00262C),
    primaryContainer = Color(0xFF093542),
    onPrimaryContainer = Color(0xFF9CF2FF),
    secondary = NeonEmerald,
    onSecondary = Color(0xFF00291B),
    secondaryContainer = Color(0xFF0A3D2C),
    onSecondaryContainer = Color(0xFFA7F3D0),
    tertiary = HotspotAmber,
    onTertiary = Color(0xFF2A1800),
    tertiaryContainer = HotspotAmberSoft,
    onTertiaryContainer = Color(0xFFFDE68A),
    background = MidnightBg,
    onBackground = TextPrimary,
    surface = Color(0xFF0D1628),
    onSurface = TextPrimary,
    surfaceVariant = MidnightCard,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    error = CoralRose,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = BarqDarkColorScheme,
            typography = AppTypography,
            content = content
        )
    }
}
